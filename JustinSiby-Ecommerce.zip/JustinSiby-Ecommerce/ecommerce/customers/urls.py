from django.urls import path
from .views import *
urlpatterns = [
    path('',view_customer,name='view_customers'),
    path('createcustomer',create_customer,name='create customer'),
    path('viewproducts',view_product,name='view_products'),
    path('addproduct/<int:id>/',add_product,name='add_product'),
    path('viewallproducts/',view_all_products,name='viewall_product'),
    path('editproduct/<int:id>',edit_product,name='edit_product'),



    path('edit/<int:id>',update,name='update user'),
    path('customer/view/',listCustomerView.as_view(),name='customer_list'),
    path('customer/create/',createCustomerView.as_view(),name='customer_create'),
    path('customer/update/<int:pk>/',updateCustomerView.as_view(),name='customer_update'),
    path('customer/delete/<int:pk>/',deleteCustomerView.as_view(),name='customer_delete'),
    path('product/create/',createProductView.as_view(),name='product_create'),
    path('product/update/<int:pk>/',updateProductView.as_view(),name='product_update'),
    path('product/delete/<int:pk>/',deleteProductView.as_view(),name='product_delete'),
]