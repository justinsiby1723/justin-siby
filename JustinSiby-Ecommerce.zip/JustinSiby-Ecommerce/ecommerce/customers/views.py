from django.shortcuts import render,redirect
from rest_framework.generics import ListAPIView,CreateAPIView,DestroyAPIView,UpdateAPIView
from customers.serializers import *
from customers.models import *

# Create your views here.

def view_customer(request):
    obj = Customer.objects.all()
    print(obj)
    return render(request,'customer.html',{'data':obj})

def create_customer(request):
    return render(request,'createcustomer.html')


def update(request,id):
    # if request.method == 'POST':
    #     name = request.POST['name']
    #     email = request.POST['email']
    #     return redirect("customer/update/id"))
    # else:
        obj = Customer.objects.get(id=id)
        return render(request,'edit.html',{'data':obj})

def view_product(request):
    obj = Products.objects.all()
    return render(request,'products.html',{'data':obj})

def add_product(request,id):
    obj = Customer.objects.get(id=id)
    return render(request,'addproduct.html',{'data':obj})

def view_all_products(request):
    obj = Products.objects.all()
    return render(request,'viewallproducts.html',{'data':obj})

def edit_product(request,id):
    obj = Products.objects.get(id=id)
    return render(request,'editproduct.html',{'data':obj})


class listCustomerView(ListAPIView):
    queryset = Customer.objects.all()
    serializer_class = customerSerializer

class createCustomerView(CreateAPIView):
    queryset = Customer.objects.all()
    serializer_class = customerSerializer

class updateCustomerView(UpdateAPIView):
    queryset = Customer.objects.all()
    serializer_class = customerSerializer

class deleteCustomerView(DestroyAPIView):
    queryset = Customer.objects.all()
    queryset.delete()

    serializer_class = customerSerializer

# product views

class listProductView(ListAPIView):
    queryset = Products.objects.all()
    serializer_class = productSerializer

class createProductView(CreateAPIView):
    queryset = Products.objects.all()
    serializer_class = productSerializer

class updateProductView(UpdateAPIView):
    queryset = Products.objects.all()
    serializer_class = productSerializer

class deleteProductView(DestroyAPIView):
    queryset = Products.objects.all()
    serializer_class = productSerializer
