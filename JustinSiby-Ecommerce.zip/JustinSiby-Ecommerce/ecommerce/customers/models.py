from django.db import models

# Create your models here.

class Customer(models.Model):
    name = models.CharField(max_length=40)
    email = models.EmailField()

    def __str__(self):
        return self.name

class Products(models.Model):
    product_name = models.CharField(max_length=100)
    customer = models.ForeignKey(Customer,on_delete=models.CASCADE)
    active = models.BooleanField(default=False)
    registered_date = models.DateField(auto_now_add=True)

    def __str__(self):
        return self.product_name
