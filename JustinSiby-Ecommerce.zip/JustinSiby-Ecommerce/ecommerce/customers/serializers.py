from rest_framework import serializers
from customers.models import *

class customerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Customer
        fields = '__all__'

class productSerializer(serializers.ModelSerializer):
    class Meta:
        model = Products
        fields = '__all__'